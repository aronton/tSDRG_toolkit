#ifndef __UNI10_ELEM_H__
#define __UNI10_ELEM_H__

#if defined(UNI_LAPACK) && defined(UNI_CPU)
#include "uni10_lapack_cpu/uni10_elem_lapack_cpu.h"
#endif

#if defined(UNI_CUSOLVER) && defined(UNI_GPU)
#include "uni10_cusolver_gpu/uni10_elem_cusolver_gpu.h"
#endif

#if defined(UNI_SCALAPACK) && defined(UNI_MPI)
#include "uni10_scalapack_mpi/uni10_elem_scalapack_mpi.h"
#endif

#endif
