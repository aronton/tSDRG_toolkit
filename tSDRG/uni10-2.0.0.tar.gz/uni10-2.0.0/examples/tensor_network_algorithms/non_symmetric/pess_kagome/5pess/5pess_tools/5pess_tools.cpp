#include "5pess_tools.h"

uni10_double64 GETREAL(uni10_double64 R){

  return R;

}

uni10_double64 GETREAL(uni10_complex128 C){

  return C.real();

}

