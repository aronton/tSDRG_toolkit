#!/bin/bash
mkdir build
cd build
cmake -DBUILD_EXAMPLES=OFF  -DCMAKE_INSTALL_PREFIX=$PREFIX $SRC_DIR
make -j4; make install

